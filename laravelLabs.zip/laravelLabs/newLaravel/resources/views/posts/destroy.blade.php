
@extends('templetes.nav')

@section('title') destroyed @endsection
@section('content')

<p class="text-danger" align="center">The post deleted</p>

@endsection